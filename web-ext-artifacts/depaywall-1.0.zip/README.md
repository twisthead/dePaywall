# dePaywall

A simple extention for Firefox. With a single click on the extention, you can remove any paywall from the webpage. 

The extention uses [12ft.io](https://12ft.io) service to remove paywalls. 
